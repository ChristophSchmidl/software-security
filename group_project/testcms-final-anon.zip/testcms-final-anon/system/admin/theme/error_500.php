<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>500 - Internal Server Error</title>

		<style>
			body {
				background: #fff;
				font-family: sans-serif;
				color: #3f3f3f;
				margin: 0;
				padding: 40px;
			}
			h1 {
				padding: 0;
				margin: 0;
			}
			a {
				color: #57829e;
			}
		</style>
	</head>
	<body>
		<h1>Internal Server Error</h1>

		<p>An error occured while we were processing your request.</p>
	</body>
</html>
