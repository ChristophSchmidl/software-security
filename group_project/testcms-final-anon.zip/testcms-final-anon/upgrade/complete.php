<!doctype html>
<html lang="en-gb">
    <head>
        <meta charset="utf-8">
        <title>Upgrade Test CMS</title>
        <mate name="robots" content="noindex, nofollow">
        <link rel="stylesheet" href="assets/css/app.css">
    </head>
    <body>
    
    	<h1><img src="assets/img/logo.gif" alt="Test CMS install logo"></h1>
    	
    	<div class="content">
    		<h2>Upgrade Complete.</h2>
    		
    		<p>Enjoy.</p>
    		
    		<p><a href="../" class="button" style="float: none; display: inline-block;">Continue to your site</a></p>
    	</div>

    </body>
</html>
